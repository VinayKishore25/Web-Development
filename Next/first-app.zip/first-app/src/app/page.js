"use client"
import { useRouter } from "next/navigation";

export default function Home() {
  const isLoggedIn = localStorage.getItem("isLoggedIn");
  const router = useRouter()
  localStorage.clear();
  if(!isLoggedIn){
    router.push("/login")
  }
  return (
    <>

      <h1>This is Home Page</h1>
    </>
  );
}
