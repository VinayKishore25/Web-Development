
export default function ProductPage() {
    return (
      <>
        <h1>This is Product Page</h1>
      </>
    );
  }
  