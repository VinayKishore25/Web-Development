const Blog = () => {
    return(
        <h1>This is Blog Page</h1>
    )
}
export default Blog;