const Blog1 = () => {
    return(
        <>
            <h1>This is Blog 1</h1>
        </>
    )
}
export default Blog1;