"use client"
const layout = ({children}) => {
    console.log(children);
  return (
    <div>
        layout
    {children}
    </div>
  )
}

export default layout