// module.exports = {
//     async redirects() {
//       return [
//         {
//           source: "/",
//           destination: "/login",
//           permanent: false,
//         },
//       ];
//     },
//   };
  