(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_login_page_a5345a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_login_page_a5345a.js",
  "chunks": [
    "static/chunks/_7922b7._.js"
  ],
  "source": "dynamic"
});
